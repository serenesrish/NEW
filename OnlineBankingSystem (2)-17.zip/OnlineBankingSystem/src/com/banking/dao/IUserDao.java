package com.banking.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.banking.model.AuthorizedUser;
import com.banking.model.Beneficiary;

@Repository
public interface IUserDao {
    public List fetchPassword(String email);

    public void AddUser(AuthorizedUser authuser);

    boolean verifyUser(String name, String password);

    public boolean chkUserBeneficiary(Beneficiary beneficiary);

}