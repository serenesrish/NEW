package com.banking.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.banking.model.Beneficiary;

@Repository
public class BeneficiaryDaoImpl implements IBeneficiaryDao {
    private static final Logger logger = LoggerFactory.getLogger(BeneficiaryDaoImpl.class);
    static Transaction tcx;
    private SessionFactory sessionFactory;

    @Autowired
    public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
    }

    /*
     * public void addBeneficiary(Beneficiary beneficiary) {
     * System.out.println("hii"); Session session =
     * this.sessionFactory.openSession(); tcx = session.beginTransaction();
     * System.out.println(beneficiary); session.save(beneficiary); tcx.commit();
     * session.close();
     * 
     * }
     * 
     * @Override public boolean chkUserBeneficiary(Beneficiary beneficiary) { //
     * TODO Auto-generated method stub return false; }
     */
    @Override
    public void addBeneficiary(Beneficiary b) {
	Session session = this.sessionFactory.getCurrentSession();
	session.persist(b);
	logger.info("Beneficiary saved successfully, Beneficiary Details=" + b);
    }

    @Override
    public void updateBeneficiary(Beneficiary b) {
	Session session = this.sessionFactory.getCurrentSession();
	session.update(b);
	logger.info("Beneficiary updated successfully, " + "Beneficiary Details=" + b);
    }

    @SuppressWarnings("unchecked")
    public List<Beneficiary> listBeneficiarys() {
	Session session = this.sessionFactory.getCurrentSession();
	List<Beneficiary> beneficiarysList = session.createQuery("from Beneficiary").list();
	for (Beneficiary b : beneficiarysList) {
	    logger.info("Beneficiary List::" + b);
	}
	return beneficiarysList;
    }

    @Override
    public Beneficiary getBeneficiaryById(int id) {
	Session session = this.sessionFactory.getCurrentSession();
	Beneficiary b = (Beneficiary) session.load(Beneficiary.class, new Integer(id));
	logger.info("Beneficiary loaded successfully, Beneficiary details=" + b);
	return b;
    }

    @Override
    public void removeBeneficiary(int id) {
	Session session = this.sessionFactory.getCurrentSession();
	Beneficiary b = (Beneficiary) session.load(Beneficiary.class, new Integer(id));
	if (null != b) {
	    session.delete(b);
	} else {
	    logger.error("Beneficiary NOT deleted, with person Id=" + id);
	}
	logger.info("Beneficiary deleted successfully, Beneficiary details=" + b);
    }

}
