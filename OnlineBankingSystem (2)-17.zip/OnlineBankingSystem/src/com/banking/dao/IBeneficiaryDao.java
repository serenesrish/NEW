package com.banking.dao;

import java.util.List;

import com.banking.model.Beneficiary;

public interface IBeneficiaryDao {

    /*
     * public void addBeneficiary(Beneficiary b);
     * 
     * public boolean chkUserBeneficiary(Beneficiary beneficiary);
     */

    public void addBeneficiary(Beneficiary b);// insert

    public void updateBeneficiary(Beneficiary b);// update/modify

    public List<Beneficiary> listBeneficiarys();// retrieve/listAll

    public Beneficiary getBeneficiaryById(int id);// search

    public void removeBeneficiary(int id);// delete/remove
}
