package com.banking.service;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.dao.IAccountDao;
import com.banking.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements IAccountService {
    private static int nextaccountNo = 1400120005;

    @Autowired
    private IAccountDao accountDao;

    @Override
    public void addAccount(Account account) {
	accountDao.addAccount(account);
    }

    @Override
    public Account getAccountDetails(long accountId) {
	return accountDao.getAccountDetails(accountId);
    }

    @Override
    public String depositAmount(long fromAccountId, long toAccountId, long amountToTransfer, String transferType) {

	String responseMessage = " ";

	Account fromAccount = accountDao.getAccountDetails(fromAccountId);
	Account toAccount = accountDao.getAccountDetails(toAccountId);

	// Assuming that NEFT will be carried out in a standard bank timings i.e. 9 AM
	// to 5 PM

	if ("NEFT".equalsIgnoreCase(transferType)) {

	    // Add logic (in below if condition, instead of true) to check if the current
	    // time is in between the 9 am to 5 pm
	    if (true)

		return "NEFT transaction can be performed in office hours only i.e. 9 AM to 5 PM";

	} else if ("IMPS".equalsIgnoreCase(transferType)) {
	    if (amountToTransfer > 200000) {
		return "IMPS transaction cant process amount greater than 2 Lakhs";
	    }
	} else if (fromAccount.getBalance() < amountToTransfer) {
	    return "Insufficient Fund";
	}

	double currentBalance = toAccount.getBalance();
	double updateBalance = currentBalance + amountToTransfer;

	toAccount.setBalance(updateBalance);

	accountDao.updateAccount(toAccount);

	responseMessage = "Amount " + amountToTransfer + " deposited to " + toAccountId + " from " + fromAccountId
		+ "On " + new Date() + "Using " + transferType + "Mode of payment";

	return responseMessage;

    }

    @Override
    public String withdrawAmount(long accountId, long amountTowithdraw) {

	String responseMessage = " ";
	double currentBalance;
	double updateBalance;

	Account account = accountDao.getAccountDetails(accountId);

	if (amountTowithdraw > account.getBalance()) {
	    return "Insufficient Fund";
	} else {
	    currentBalance = account.getBalance();
	    updateBalance = currentBalance - amountTowithdraw;

	}
	account.setBalance(updateBalance);
	accountDao.updateAccount(account);
	responseMessage = "Amount " + amountTowithdraw + " withdrawn from " + accountId + " On " + new Date();
	return responseMessage;

    }

    private int accountGen() {
	return ++nextaccountNo;
    }

    @Override
    public String fundTransfer(long fromAccount, long toAccount, long Amount) {
	// TODO Auto-generated method stub
	return null;
    }

}
