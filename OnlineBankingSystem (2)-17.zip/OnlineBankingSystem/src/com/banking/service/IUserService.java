package com.banking.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.banking.model.AuthorizedUser;
import com.banking.model.Beneficiary;

@Service
public interface IUserService {
    List fetchPassword(String email);

    public void AddUser(AuthorizedUser authuser);

    boolean verifyUser(String name, String password);

    public boolean chkUserBeneficiary(Beneficiary beneficiary);
}
