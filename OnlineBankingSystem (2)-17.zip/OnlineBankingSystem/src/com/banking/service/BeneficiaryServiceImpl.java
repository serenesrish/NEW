package com.banking.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.dao.IBeneficiaryDao;
import com.banking.model.Beneficiary;

@Service
@Transactional

public abstract class BeneficiaryServiceImpl implements IBeneficiaryService {
    private IBeneficiaryDao beneficiaryDao;

    // setter method for personDao
    @Autowired
    public void setBeneficiaryDao(IBeneficiaryDao beneficiaryDao) {
	this.beneficiaryDao = beneficiaryDao;
    }

    @Override
    @Transactional
    public void addBeneficiary(Beneficiary b) {
	this.beneficiaryDao.addBeneficiary(b);
    }

    @Transactional
    public void updateBeneficiary(Beneficiary b) {
	this.beneficiaryDao.updateBeneficiary(b);
    }

    @Transactional
    public List<Beneficiary> listBeneficiarys() {
	return this.beneficiaryDao.listBeneficiarys();
    }

    @Transactional
    public Beneficiary getBeneficiaryById(int id) {
	return this.beneficiaryDao.getBeneficiaryById(id);
    }

    @Transactional
    public void removeBeneficiary(int id) {
	this.beneficiaryDao.removeBeneficiary(id);
    }
}

/*
 * @Override public void addBeneficiary(Beneficiary beneficiary) { // TODO
 * Auto-generated method stub System.out.println("hii");
 * this.beneficiaryDao.addBeneficiary(beneficiary); }
 * 
 * public Beneficiary getBeneficiary(int beneficiaryid) { return
 * beneficiaryDao.getBeneficiary(beneficiaryid); }
 * 
 * @Override public boolean chkUserBeneficiary(Beneficiary beneficiary) { //
 * TODO Auto-generated method stub return
 * this.beneficiaryDao.chkUserBeneficiary(beneficiary); }
 */
