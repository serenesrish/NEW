package com.banking.service;

import java.util.List;

import com.banking.model.Beneficiary;

public interface IBeneficiaryService {

    public void addBeneficiary(Beneficiary p);

    public void updateBeneficiary(Beneficiary p);

    public List<Beneficiary> listBeneficiarys();

    public Beneficiary getBeneficiaryById(int id);

    public void removeBeneficiary(int id);

}