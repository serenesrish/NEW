package com.banking.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.dao.IUserDao;
import com.banking.model.AuthorizedUser;
import com.banking.model.Beneficiary;

@Service
@Transactional
public class UserServiceImpl implements IUserService {
    @Autowired
    IUserDao UserDao;

    public void setUserDao(IUserDao userDao) {
	UserDao = userDao;
    }

    @Override
    public List fetchPassword(String email) {

	return UserDao.fetchPassword(email);
    }

    @Override

    public void AddUser(AuthorizedUser authuser) {
	// TODO Auto-generated method stub
	UserDao.AddUser(authuser);
    }

    @Override
    public boolean verifyUser(String name, String password) {
	return UserDao.verifyUser(name, password);
    }

    @Override
    public boolean chkUserBeneficiary(Beneficiary beneficiary) {
	// TODO Auto-generated method stub
	return false;
    }
}
